var searchData=
[
  ['has_5fsdio_5fclass_0',['HAS_SDIO_CLASS',['../_sd_fat_config_8h.html#a356309f8e0bad852d7a07ad0b9326a27',1,'SdFatConfig.h']]],
  ['has_5funused_5fstack_1',['HAS_UNUSED_STACK',['../_free_stack_8h.html#acd5a8222ee7af79faab74b1df412d600',1,'FreeStack.h']]]
];
