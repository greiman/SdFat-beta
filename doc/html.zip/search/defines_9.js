var searchData=
[
  ['use_5fblock_5fdevice_5finterface_0',['USE_BLOCK_DEVICE_INTERFACE',['../_sd_fat_config_8h.html#ae92cc0fb2a31925cfc5694feb048dca2',1,'SdFatConfig.h']]],
  ['use_5fexfat_5fbitmap_5fcache_1',['USE_EXFAT_BITMAP_CACHE',['../_sd_fat_config_8h.html#a8d3fca2607182c1ba389dd61c283a3e2',1,'SdFatConfig.h']]],
  ['use_5ffat_5ffile_5fflag_5fcontiguous_2',['USE_FAT_FILE_FLAG_CONTIGUOUS',['../_sd_fat_config_8h.html#ad42a354208ecb245adfc238266a612e5',1,'SdFatConfig.h']]],
  ['use_5ffcntl_5fh_3',['USE_FCNTL_H',['../_sd_fat_config_8h.html#ab4b7255422e65730612f1f6af1a26752',1,'SdFatConfig.h']]],
  ['use_5flong_5ffile_5fnames_4',['USE_LONG_FILE_NAMES',['../_sd_fat_config_8h.html#a2536b194b3b007604a39e8526e108b52',1,'SdFatConfig.h']]],
  ['use_5fmulti_5fsector_5fio_5',['USE_MULTI_SECTOR_IO',['../_sd_fat_config_8h.html#ae477a983188d4370faff32b07a5cfacb',1,'SdFatConfig.h']]],
  ['use_5fsd_5fcrc_6',['USE_SD_CRC',['../_sd_fat_config_8h.html#af2e76ffb2fdb830175abf513dd640fdd',1,'SdFatConfig.h']]],
  ['use_5fseparate_5ffat_5fcache_7',['USE_SEPARATE_FAT_CACHE',['../_sd_fat_config_8h.html#a23f662882413dcb017ebd8107473b8c3',1,'SdFatConfig.h']]],
  ['use_5fsimple_5flittle_5fendian_8',['USE_SIMPLE_LITTLE_ENDIAN',['../_sd_fat_config_8h.html#a9d4fac424e31b4383a10211f0489d93b',1,'SdFatConfig.h']]],
  ['use_5fspi_5farray_5ftransfer_9',['USE_SPI_ARRAY_TRANSFER',['../_sd_fat_config_8h.html#a530450ba9acb3bd89b63ac0c390c9807',1,'SdFatConfig.h']]],
  ['use_5futf8_5flong_5fnames_10',['USE_UTF8_LONG_NAMES',['../_sd_fat_config_8h.html#a02a722792ca0b003c1b9330f0dee5f11',1,'SdFatConfig.h']]]
];
