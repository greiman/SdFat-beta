var searchData=
[
  ['ostream_2eh_0',['ostream.h',['../ostream_8h.html',1,'']]]
];
